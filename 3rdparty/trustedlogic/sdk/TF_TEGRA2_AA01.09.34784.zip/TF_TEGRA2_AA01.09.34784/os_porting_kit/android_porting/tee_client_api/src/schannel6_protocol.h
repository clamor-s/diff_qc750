/*
 * Copyright (c) 2011 Trusted Logic S.A.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Trusted Logic S.A. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered
 * into with Trusted Logic S.A.
 *
 * TRUSTED LOGIC S.A. MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. TRUSTED LOGIC S.A. SHALL
 * NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

#ifndef __SCHANNEL6_PROTOCOL_H__
#define __SCHANNEL6_PROTOCOL_H__

#include "s_type.h"

/**
 * Time representation.
 */
typedef uint64_t SCTIME;

#define SCTIME_IMMEDIATE ((uint64_t) 0x0000000000000000ULL)
#define SCTIME_INFINITE  ((uint64_t) 0xFFFFFFFFFFFFFFFFULL)

/*
 * Message types
 */
#define SCX_CREATE_DEVICE_CONTEXT   0x02
#define SCX_DESTROY_DEVICE_CONTEXT  0xFD
#define SCX_REGISTER_SHARED_MEMORY  0xF7
#define SCX_RELEASE_SHARED_MEMORY   0xF9
#define SCX_OPEN_CLIENT_SESSION     0xF0
#define SCX_CLOSE_CLIENT_SESSION    0xF2
#define SCX_INVOKE_CLIENT_COMMAND   0xF5
#define SCX_CANCEL_CLIENT_OPERATION 0xF4
#define SCX_MANAGEMENT              0xFE

/*
 * Shared mem flags
 */
#define SCX_SHARED_MEM_FLAG_INPUT   1
#define SCX_SHARED_MEM_FLAG_OUTPUT  2
#define SCX_SHARED_MEM_FLAG_INOUT   3

/* 
 * Parameter types
 */
#define SCX_PARAM_TYPE_NONE                     0x0
#define SCX_PARAM_TYPE_VALUE_INPUT              0x1
#define SCX_PARAM_TYPE_VALUE_OUTPUT             0x2
#define SCX_PARAM_TYPE_VALUE_INOUT              0x3
#define SCX_PARAM_TYPE_MEMREF_TEMP_INPUT        0x5
#define SCX_PARAM_TYPE_MEMREF_TEMP_OUTPUT       0x6
#define SCX_PARAM_TYPE_MEMREF_TEMP_INOUT        0x7
#define SCX_PARAM_TYPE_MEMREF_INPUT             0xD
#define SCX_PARAM_TYPE_MEMREF_OUTPUT            0xE
#define SCX_PARAM_TYPE_MEMREF_INOUT             0xF

#define SCX_PARAM_TYPE_INPUT_FLAG                0x1
#define SCX_PARAM_TYPE_OUTPUT_FLAG               0x2
#define SCX_PARAM_TYPE_MEMREF_FLAG               0x4
#define SCX_PARAM_TYPE_REGISTERED_MEMREF_FLAG    0x8

#define SCX_PARAM_TYPE_IS_TMPREF(nParamType) (((nParamType) & (SCX_PARAM_TYPE_MEMREF_FLAG | SCX_PARAM_TYPE_REGISTERED_MEMREF_FLAG)) == SCX_PARAM_TYPE_MEMREF_FLAG)

#define SCX_MAKE_PARAM_TYPES(t0, t1, t2, t3) ((t0) | ((t1) << 4) | ((t2) << 8) | ((t3) << 12))
#define SCX_GET_PARAM_TYPE(t, i) (((t) >> (4*i)) & 0xF)

/*
 * return origins 
 */
#define SCX_ORIGIN_COMMS       2
#define SCX_ORIGIN_TEE         3
#define SCX_ORIGIN_TRUSTED_APP 4

/*
 * Login types
 */
#include "schannel6_logins.h"

/*
 * Limits and sizes
 */

/* Maximum number of L1 descriptors covered by a registered shared memory block.
   Must be kept in synch with TF_MAX_COARSE_PAGES in tf_protocol.h
   in the Linux kernel driver. */
#define SCHANNEL6_MAX_DESCRIPTORS_PER_REGISTERED_SHARED_MEM 128

/**
 * Command parameters.
 */
typedef struct
{
   uint32_t    a;
   uint32_t    b;
}SCHANNEL6_COMMAND_PARAM_VALUE;

typedef struct
{
   uint32_t    nDescriptor; 
   uint32_t    nSize;
   uint32_t    nOffset;     /* Socket: 4 weak bits of the address (for alignement checks) */

}SCHANNEL6_COMMAND_PARAM_TEMP_MEMREF;

typedef struct
{
   S_HANDLE    hBlock;
   uint32_t    nSize;
   uint32_t    nOffset;

}SCHANNEL6_COMMAND_PARAM_MEMREF;

typedef union
{
   SCHANNEL6_COMMAND_PARAM_VALUE        sValue;
   SCHANNEL6_COMMAND_PARAM_TEMP_MEMREF  sTempMemref;
   SCHANNEL6_COMMAND_PARAM_MEMREF       sMemref;

} SCHANNEL6_COMMAND_PARAM;

typedef struct
{
   uint32_t a;
   uint32_t b;
} SCHANNEL6_ANSWER_PARAM_VALUE;

typedef struct
{
   uint32_t _ignored;
   uint32_t nSize;
} SCHANNEL6_ANSWER_PARAM_SIZE;

typedef union
{
   SCHANNEL6_ANSWER_PARAM_SIZE  sSize;
   SCHANNEL6_ANSWER_PARAM_VALUE sValue;
} SCHANNEL6_ANSWER_PARAM;

/**
 * Command messages.
 */
 typedef struct
{
   uint8_t                       nMessageSize;
   uint8_t                       nMessageType;
   uint16_t                      nMessageInfo;
   uint32_t                      nOperationID; /* an opaque Normal World identifier for the operation */
}SCHANNEL6_COMMAND_HEADER;

typedef struct
{
   uint8_t                       nMessageSize;
   uint8_t                       nMessageType;
   uint16_t                      nMessageInfo_RFU;
   uint32_t                      nOperationID; /* an opaque Normal World identifier for the operation */
   uint32_t                      nDeviceContextID; /* an opaque Normal World identifier for the device context */
}SCHANNEL6_CREATE_DEVICE_CONTEXT_COMMAND;

typedef struct
{
   uint8_t                       nMessageSize;
   uint8_t                       nMessageType;
   uint16_t                      nParamTypes;
   uint32_t                      nOperationID; /* an opaque Normal World identifier for the operation */
   S_HANDLE                      hDeviceContext;
   S_HANDLE                      hClientSession;
   uint64_t                      sTimeout;
   uint32_t                      nCancellationID;
   uint32_t                      nClientCommandIdentifier;
   SCHANNEL6_COMMAND_PARAM       sParams[4];
}SCHANNEL6_INVOKE_CLIENT_COMMAND_COMMAND;

typedef struct
{
   uint8_t                       nMessageSize;
   uint8_t                       nMessageType;
   uint16_t                      nParamTypes;
   uint32_t                      nOperationID; /* an opaque Normal World identifier for the operation */
   S_HANDLE                      hDeviceContext;
   uint32_t                      nCancellationID;
   SCTIME                        sTimeout;
   S_UUID                        sDestinationUUID;
   SCHANNEL6_COMMAND_PARAM       sParams[4];
   uint32_t                      nLoginType;
   uint8_t                       sLoginData[20]; /* Size depends on the login type. */

}SCHANNEL6_OPEN_CLIENT_SESSION_COMMAND;

typedef struct
{
   uint8_t                       nMessageSize;
   uint8_t                       nMessageType;
   uint16_t                      nMemoryFlags;
   uint32_t                      nOperationID; /* an opaque Normal World identifier for the operation */
   S_HANDLE                      hDeviceContext;
   uint32_t                      nBlockID;
   uint32_t                      nSharedMemSize;
   uint32_t                      nSharedMemStartOffset;
   uint32_t                      nSharedMemDescriptors[SCHANNEL6_MAX_DESCRIPTORS_PER_REGISTERED_SHARED_MEM];

}SCHANNEL6_REGISTER_SHARED_MEMORY_COMMAND;

typedef struct
{
   uint8_t                       nMessageSize;
   uint8_t                       nMessageType;
   uint16_t                      nMessageInfo_RFU;
   uint32_t                      nOperationID; /* an opaque Normal World identifier for the operation */
   S_HANDLE                      hDeviceContext;
   S_HANDLE                      hBlock;

}SCHANNEL6_RELEASE_SHARED_MEMORY_COMMAND;

typedef struct
{
   uint8_t                       nMessageSize;
   uint8_t                       nMessageType;
   uint16_t                      nMessageInfo_RFU;
   uint32_t                      nOperationID; /* an opaque Normal World identifier for the operation */
   S_HANDLE                      hDeviceContext;
   S_HANDLE                      hClientSession;
   uint32_t                      nCancellationID;

}SCHANNEL6_CANCEL_CLIENT_OPERATION_COMMAND;

typedef struct
{
   uint8_t                       nMessageSize;
   uint8_t                       nMessageType;
   uint16_t                      nMessageInfo_RFU;
   uint32_t                      nOperationID; /* an opaque Normal World identifier for the operation */
   S_HANDLE                      hDeviceContext;
   S_HANDLE                      hClientSession;

}SCHANNEL6_CLOSE_CLIENT_SESSION_COMMAND;

typedef struct
{
   uint8_t                       nMessageSize;
   uint8_t                       nMessageType;
   uint16_t                      nMessageInfo_RFU;
   uint32_t                      nOperationID; /* an opaque Normal World identifier for the operation */
   S_HANDLE                      hDeviceContext;

}SCHANNEL6_DESTROY_DEVICE_CONTEXT_COMMAND;

#define SCHANNEL6_MANAGEMENT_COMMAND_HIBERNATE            1
#define SCHANNEL6_MANAGEMENT_COMMAND_SHUTDOWN             2
#define SCHANNEL6_MANAGEMENT_COMMAND_PREPARE_FOR_CORE_OFF 3
#define SCHANNEL6_MANAGEMENT_COMMAND_RESUME_FROM_CORE_OFF 4

typedef struct
{
   uint8_t                       nMessageSize;
   uint8_t                       nMessageType;
   uint16_t                      nCommand;
   uint32_t                      nOperationID; /* an opaque Normal World identifier for the operation */
   uint32_t                      nW3BSize;
   uint32_t                      nW3BStartOffset;
#ifdef SCHANNEL_TRUSTZONE
   uint32_t                      nSharedMemDescriptors[128];
#endif
}SCHANNEL6_MANAGEMENT_COMMAND;

typedef union
{
   SCHANNEL6_COMMAND_HEADER                            sHeader;
   SCHANNEL6_CREATE_DEVICE_CONTEXT_COMMAND             sCreateDeviceContext;
   SCHANNEL6_DESTROY_DEVICE_CONTEXT_COMMAND            sDestroyDeviceContext;
   SCHANNEL6_OPEN_CLIENT_SESSION_COMMAND               sOpenClientSession;
   SCHANNEL6_CLOSE_CLIENT_SESSION_COMMAND              sCloseClientSession;
   SCHANNEL6_REGISTER_SHARED_MEMORY_COMMAND            sRegisterSharedMemory;
   SCHANNEL6_RELEASE_SHARED_MEMORY_COMMAND             sReleaseSharedMemory;
   SCHANNEL6_INVOKE_CLIENT_COMMAND_COMMAND             sInvokeClientCommand;
   SCHANNEL6_CANCEL_CLIENT_OPERATION_COMMAND           sCancelClientOperation;
   SCHANNEL6_MANAGEMENT_COMMAND                        sManagement;

}SCHANNEL6_COMMAND;

/**
 * Answer messages.
 */
typedef struct
{
   uint8_t                   nMessageSize;
   uint8_t                   nMessageType;
   uint16_t                  nMessageInfo;
   uint32_t                  nOperationID;
   uint32_t                  nErrorCode;
}SCHANNEL6_ANSWER_HEADER;

typedef struct
{
   uint8_t                   nMessageSize;
   uint8_t                   nMessageType;
   uint16_t                  nMessageInfo_RFU;
   uint32_t                  nOperationID;
   uint32_t                  nErrorCode;
   S_HANDLE                  hDeviceContext;
}SCHANNEL6_CREATE_DEVICE_CONTEXT_ANSWER;

typedef struct
{
   uint8_t                   nMessageSize;
   uint8_t                   nMessageType;
   uint8_t                   nReturnOrigin;
   uint8_t                   __nReserved;
   uint32_t                  nOperationID;
   uint32_t                  nErrorCode;
   SCHANNEL6_ANSWER_PARAM    sAnswers[4];

}SCHANNEL6_INVOKE_CLIENT_COMMAND_ANSWER;

typedef struct
{
   uint8_t                   nMessageSize;
   uint8_t                   nMessageType;
   uint8_t                   nReturnOrigin;
   uint8_t                   __nReserved;
   uint32_t                  nOperationID;
   uint32_t                  nErrorCode;
   S_HANDLE                  hClientSession;
   SCHANNEL6_ANSWER_PARAM    sAnswers[4];
}SCHANNEL6_OPEN_CLIENT_SESSION_ANSWER;

typedef struct
{
   uint8_t                   nMessageSize;
   uint8_t                   nMessageType;
   uint16_t                  nMessageInfo_RFU;
   uint32_t                  nOperationID;
   uint32_t                  nErrorCode;
}SCHANNEL6_CLOSE_CLIENT_SESSION_ANSWER;

typedef struct
{
   uint8_t                   nMessageSize;
   uint8_t                   nMessageType;
   uint16_t                  nMessageInfo_RFU;
   uint32_t                  nOperationID;
   uint32_t                  nErrorCode;
   S_HANDLE                  hBlock;

}SCHANNEL6_REGISTER_SHARED_MEMORY_ANSWER;

typedef struct
{
   uint8_t                   nMessageSize;
   uint8_t                   nMessageType;
   uint16_t                  nMessageInfo_RFU;
   uint32_t                  nOperationID;
   uint32_t                  nErrorCode;
   uint32_t                  nBlockID;

}SCHANNEL6_RELEASE_SHARED_MEMORY_ANSWER;

typedef struct
{
   uint8_t                   nMessageSize;
   uint8_t                   nMessageType;
   uint16_t                  nMessageInfo_RFU;
   uint32_t                  nOperationID;
   uint32_t                  nErrorCode;
   uint32_t                  nDeviceContextID;

}SCHANNEL6_DESTROY_DEVICE_CONTEXT_ANSWER;

typedef struct
{
   uint8_t                   nMessageSize;
   uint8_t                   nMessageType;
   uint16_t                  nMessageInfo_RFU;
   uint32_t                  nOperationID;
   uint32_t                  nErrorCode;

}SCHANNEL6_CANCEL_CLIENT_OPERATION_ANSWER;

typedef struct
{
   uint8_t                   nMessageSize;
   uint8_t                   nMessageType;
   uint16_t                  nMessageInfo_RFU;
   uint32_t                  nOperationID;
   uint32_t                  nErrorCode;

}SCHANNEL6_MANAGEMENT_ANSWER;

typedef union
{
   SCHANNEL6_ANSWER_HEADER                    sHeader;
   SCHANNEL6_CREATE_DEVICE_CONTEXT_ANSWER     sCreateDeviceContext;
   SCHANNEL6_OPEN_CLIENT_SESSION_ANSWER       sOpenClientSession;
   SCHANNEL6_REGISTER_SHARED_MEMORY_ANSWER    sRegisterSharedMemory;
   SCHANNEL6_RELEASE_SHARED_MEMORY_ANSWER     sReleaseSharedMemory;
   SCHANNEL6_INVOKE_CLIENT_COMMAND_ANSWER     sInvokeClientCommand;
   SCHANNEL6_DESTROY_DEVICE_CONTEXT_ANSWER    sDestroyDeviceContext;
   SCHANNEL6_CANCEL_CLIENT_OPERATION_ANSWER   sCancelClientOperation;
   SCHANNEL6_CLOSE_CLIENT_SESSION_ANSWER      sCloseClientSession;
   SCHANNEL6_MANAGEMENT_ANSWER                sManagement;

}SCHANNEL6_ANSWER;


#endif /* __SCHANNEL6_PROTOCOL_H__ */
